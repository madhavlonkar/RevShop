-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: revshoprevature
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_order`
--

DROP TABLE IF EXISTS `tbl_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_order` (
  `orderId` varchar(255) NOT NULL,
  `sellerId` int DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `productName` varchar(45) NOT NULL,
  `totalPrice` double NOT NULL,
  `productId` int NOT NULL,
  `quantity` int NOT NULL,
  `imgUrl` mediumtext NOT NULL,
  `status` varchar(45) NOT NULL,
  `transactionId` varchar(255) NOT NULL,
  `shippingAddress` mediumtext NOT NULL,
  PRIMARY KEY (`orderId`),
  KEY `sellerId` (`sellerId`),
  KEY `userId` (`userId`),
  CONSTRAINT `tbl_order_ibfk_1` FOREIGN KEY (`sellerId`) REFERENCES `tbl_user` (`userId`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tbl_order_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `tbl_user` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_order`
--

LOCK TABLES `tbl_order` WRITE;
/*!40000 ALTER TABLE `tbl_order` DISABLE KEYS */;
INSERT INTO `tbl_order` VALUES ('OD17251711188769354',1,3,'SmartWatch Pro X',4499,2,2,'Static/img/home/smartwatch2.webp','In Transit','pay_OrnZvpFM16Tww4','A/P: Korhale BK,Tal-Baramati,Dist-Pune, PUNE, MAHARASHTRA, 412103'),('OD17251711195588021',2,3,'Faltu Product',2294,14,1,'Static/img/home/HarryPotter8BookSet_1.webp','Delivered','pay_OrnZvpFM16Tww4','A/P: Korhale BK,Tal-Baramati,Dist-Pune, PUNE, MAHARASHTRA, 412103'),('OD17252591322553670',1,3,'SmartWatch Pro X',4499,2,2,'Static/img/home/smartwatch2.webp','In Transit','pay_OsCZCDPZly5DXO','Chanda Apartmenet,Shivajirao kadam gali,1,shiv colony,Ambegaon Pathar,Dhankawadi, Pune, Maharashtra, 411046');
/*!40000 ALTER TABLE `tbl_order` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-03 16:14:03
