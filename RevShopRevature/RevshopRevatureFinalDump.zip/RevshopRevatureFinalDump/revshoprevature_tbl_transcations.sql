-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: revshoprevature
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_transcations`
--

DROP TABLE IF EXISTS `tbl_transcations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_transcations` (
  `transcation_id` varchar(255) NOT NULL,
  `orderId` varchar(255) NOT NULL,
  `amount` double NOT NULL,
  `userId` int NOT NULL,
  `sellerId` int NOT NULL,
  PRIMARY KEY (`transcation_id`),
  KEY `tbl_transcations_ibfk_1` (`orderId`),
  KEY `tbl_transcations_ibfk_2` (`userId`),
  KEY `tbl_transcations_ibfk_3` (`sellerId`),
  CONSTRAINT `tbl_transcations_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `tbl_order` (`orderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_transcations_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `tbl_user` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_transcations_ibfk_3` FOREIGN KEY (`sellerId`) REFERENCES `tbl_user` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_transcations`
--

LOCK TABLES `tbl_transcations` WRITE;
/*!40000 ALTER TABLE `tbl_transcations` DISABLE KEYS */;
INSERT INTO `tbl_transcations` VALUES ('pay_OrnZvpFM16Tww4','OD17251711188769354',4499,3,1),('pay_OsCZCDPZly5DXO','OD17252591322553670',4499,3,1);
/*!40000 ALTER TABLE `tbl_transcations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-03 16:14:02
