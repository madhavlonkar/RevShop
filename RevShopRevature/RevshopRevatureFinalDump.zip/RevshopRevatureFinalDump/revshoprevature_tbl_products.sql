-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: revshoprevature
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_products`
--

DROP TABLE IF EXISTS `tbl_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_products` (
  `productId` int NOT NULL AUTO_INCREMENT,
  `productName` varchar(45) NOT NULL,
  `productDescription` mediumtext NOT NULL,
  `productPrice` double NOT NULL,
  `productDiscount` double DEFAULT NULL,
  `productStock` int NOT NULL,
  `productImage` varchar(255) NOT NULL,
  `productBrand` varchar(45) NOT NULL,
  `productCategory` varchar(45) NOT NULL,
  `productTags` mediumtext,
  `productStatus` varchar(45) NOT NULL,
  `sellerId` int NOT NULL,
  `threshold` int NOT NULL,
  PRIMARY KEY (`productId`),
  KEY `tbl_products_ibfk_1` (`sellerId`),
  CONSTRAINT `tbl_products_ibfk_1` FOREIGN KEY (`sellerId`) REFERENCES `tbl_user` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_products`
--

LOCK TABLES `tbl_products` WRITE;
/*!40000 ALTER TABLE `tbl_products` DISABLE KEYS */;
INSERT INTO `tbl_products` VALUES (2,'SmartWatch Pro X','The SmartWatch Pro X combines cutting-edge technology with a sleek design, offering advanced fitness tracking, heart rate monitoring, and seamless connectivity to your smartphone. With a long-lasting battery, water resistance, and customizable watch faces, it’s the perfect companion for both everyday wear and intense workouts. Stay connected, stay fit, and stay stylish with the SmartWatch Pro X.',4999,10,96,'Static/img/home/smartwatch2.webp','TechWear','electronics','smartwatch, fitness, new, bestseller','In_Stock',1,20),(3,'Classic Leather Jacket','A timeless piece for any wardrobe, the Classic Leather Jacket is made from premium leather, featuring a modern cut and durable stitching. Perfect for a casual look or a night out.',899,20,500,'Static/img/home/jacket.png','UrbanWear','fashion','leather, jacket, fashion, bestseller','In_Stock',1,100),(4,'SuperClean Vacuum 3000','The SuperClean Vacuum 3000 offers powerful suction with advanced HEPA filtration, making it the perfect solution for a spotless home. With multiple attachments and easy maneuverability, cleaning has never been easier.',2999,0,15,'Static/img/home/Vacuum.webp','CleanMax','HomeAppliances','vacuum, home, appliances, new','In_Stock',1,10),(5,'The Art of Coding','Dive into the world of software development with \"The Art of Coding,\" a comprehensive guide that covers the basics to advanced concepts. Perfect for beginners and seasoned programmers alike.',599,20,100,'Static/img/home/artofcodingbook.jpg','CodeMaster Press','Books','coding, books, programming, education','In_Stock',1,50),(7,'Poco M2 Pro','The Poco is a flagship smartphone that redefines mobile technology with its 6.2-inch Dynamic AMOLED display, offering vibrant colors and deep contrasts. It features a powerful Exynos 2100 processor paired with 8GB RAM, ensuring seamless multitasking and gaming experiences. The device comes with 128GB of internal storage, perfect for all your apps, photos, and files. The 64MP triple camera system captures stunning photos and videos, even in low light.',15000,12,100,'Static/img/home/Mpoco.jpg','POCO','electronics','sale, new, smartphone, flagship','In_Stock',2,20),(8,'Apple MacBook Pro 13-inch','The Apple MacBook Pro 13-inch is a powerhouse of performance in a sleek, portable design. Featuring the latest Apple M1 chip, this laptop delivers unprecedented speed and efficiency, making multitasking and running demanding applications a breeze. With a stunning Retina display, the MacBook Pro offers vibrant colors and sharp details, perfect for creative professionals and everyday users alike. The magic keyboard and Force Touch trackpad provide a comfortable and precise typing experience, while the long battery life keeps you powered throughout the day.',130000,15,100,'Static/img/home/apple.png','Apple','electronics','premium, laptop, apple, new','In_Stock',2,10),(9,'Sony WH-1000XM4 Headphones','The Sony WH-1000XM4 headphones are the epitome of audio excellence, offering industry-leading noise cancellation and unparalleled sound quality. These wireless over-ear headphones are equipped with dual noise sensor technology, allowing you to immerse yourself in your music, free from external distractions. The adaptive sound control feature automatically adjusts the ambient sound settings based on your surroundings, ensuring the perfect listening experience.',2999,10,100,'Static/img/home/headphones.jpg','Sony','electronics','bestseller, new, audio, premium,bluetooth','In_Stock',2,20),(10,'Nike Air Max 270','The Nike Air Max 270 is the ultimate blend of style and comfort, making it one of the most sought-after sneakers in the market. Featuring a large, visible Air unit in the heel, these shoes provide exceptional cushioning and a smooth ride. The upper is crafted from lightweight and breathable mesh, ensuring your feet stay cool and comfortable throughout the day.',1059,10,80,'Static/img/home/nike.jpeg','Nike','fashion','bestseller, trendy, sportswear, sneakers','In_Stock',2,50),(11,'Philips Air Fryer XXL','The Philips Air Fryer XXL is a kitchen must-have for health-conscious individuals looking to enjoy fried foods without the guilt. Using Rapid Air technology, this air fryer cooks food with up to 90% less fat, making your meals healthier without compromising on taste. It has a large capacity, allowing you to cook for the entire family in one go. The digital interface provides easy control over cooking times and temperatures, ensuring perfect results every time.',499,0,50,'Static/img/home/airfryer.webp','Philips','HomeAppliances','new, kitchen, healthy, appliance','In_Stock',2,25),(12,'The Alchemist','\"The Alchemist\" by Paulo Coelho is a timeless masterpiece that has touched the hearts of millions worldwide. This philosophical novel tells the story of Santiago, a young shepherd who embarks on a journey to find a worldly treasure. Along the way, he learns profound lessons about the nature of dreams, the importance of listening to one\'s heart, and the true meaning of life. The Alchemist is celebrated for its inspiring message, poetic prose, and its ability to resonate with readers from all walks of life. It is a must-read for anyone seeking purpose and direction.',499,0,159,'Static/img/home/TheAlchemist.jpg','HarperCollins','Books','bestseller, classic, fiction, inspiration','In_Stock',2,50),(13,'Yonex Badminton Racket','The Yonex Badminton Racket is engineered for players who demand precision and power in their game. Made with high-quality graphite, this racket offers an excellent balance between weight and strength, providing unmatched control and speed. Its isometric head shape expands the sweet spot, ensuring you get the best shot even on off-center hits. Designed for both beginners and professional players, this racket enhances your performance on the court, making it a trusted choice in tournaments worldwide. With its sleek design and superior build, the Yonex Badminton Racket is a game-changer.',2999,15,30,'Static/img/home/wilsontennis.webp','Yonex','Sports','new, sports, durable, professional','In_Stock',2,10);
/*!40000 ALTER TABLE `tbl_products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-03 16:14:02
